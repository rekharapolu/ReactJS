package spring_ioc_container.constructor_injection;

public class Car {
	int cid;
	String name;
	String model;
	double cost;
	Engine engine;
	public Car(int cid, String name, String model, double cost, Engine engine) {
		
		this.cid = cid;
		this.name = name;
		this.model = model;
		this.cost = cost;
		this.engine = engine;
	}
	public void carDetails() {
		System.out.println(cid);
		System.out.println(name);
		System.out.println(model);
		System.out.println(cost);
		System.out.println(engine.eno);
		System.out.println(engine.cc);
	}
}
