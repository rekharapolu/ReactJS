package spring_ioc_container;

public class Bike {
	public void start() {
		System.out.println("bike started.....");
	}
	public void stop() {
		System.out.println("bike stopped.....");
	}
}
