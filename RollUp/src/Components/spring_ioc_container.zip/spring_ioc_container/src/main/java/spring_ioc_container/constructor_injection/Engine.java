package spring_ioc_container.constructor_injection;

public class Engine {
	int eno;
	double cc;
	public Engine(int eno, double cc) {
		super();
		this.eno = eno;
		this.cc = cc;
	}
	public void engDetails() {
		System.out.println(eno);
		System.out.println(cc);
	}
	
		

	

}
