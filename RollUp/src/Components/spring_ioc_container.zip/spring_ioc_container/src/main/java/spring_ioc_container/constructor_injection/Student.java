package spring_ioc_container.constructor_injection;

import java.util.Set;

public class Student {
	private String sid;
	private String name;
	private String branch;
	private Set<String>skills;
	public Student(String sid, String name, String branch, Set<String> skills) {
		
		this.sid = sid;
		this.name = name;
		this.branch = branch;
		this.skills = skills;
	}
	public void studentDetails() {
		System.out.println(sid);
		System.out.println(name);
		System.out.println(branch);
		System.out.println(skills);
	}
}
