package spring_ioc_container.constructor_injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GunDriver {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("gun.xml");
		Gun gun =(Gun)context.getBean("mygun");
		gun.gunDetails();
	}

}
