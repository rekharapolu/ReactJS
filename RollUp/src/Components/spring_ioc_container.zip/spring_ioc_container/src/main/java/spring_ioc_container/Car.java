package spring_ioc_container;

public class Car {
	public double cost(double cost) {
		return cost;
		
	}
	public void start() {
		System.out.println("car started.....");
	}
	
	
}
