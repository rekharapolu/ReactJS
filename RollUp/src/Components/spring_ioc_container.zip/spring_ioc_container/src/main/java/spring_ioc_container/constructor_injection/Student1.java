package spring_ioc_container.constructor_injection;

import java.util.Map;

public class Student1 {
    private String sid;
    private String name;
    private String branch;
    private Map<String, String> skills; // Using Map instead of Set

    public Student1(String sid, String name, String branch, Map<String, String> skills) {
        this.sid = sid;
        this.name = name;
        this.branch = branch;
        this.skills = skills;
    }

    public void studentDetails() {
        System.out.println(sid);
        System.out.println(name);
        System.out.println( branch);
        System.out.println(skills);
        
    }
}
