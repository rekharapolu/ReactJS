package spring_ioc_container.constructor_injection;

import java.util.List;

public class Employee {
	String name;
	double salary;
	String address;
	List<String>skill;
	public Employee(String name, double salary, String address, List<String> skill) {
		super();
		this.name = name;
		this.salary = salary;
		this.address = address;
		this.skill = skill;
	}
	public void employeeDetails() {
		System.out.println(name);
		System.out.println(salary);
		System.out.println(address);
		System.out.println(skill);
	}
}

