package spring_ioc_container.constructor_injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentDriver1 {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("student1.xml");
		Student1 student=(Student1)context.getBean("student1");
		student.studentDetails();

	}
}
