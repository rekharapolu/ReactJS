package spring_ioc_container.constructor_injection;

public class Gun {
	String name;
	double cost;
	public Gun(String name, double cost) {
		this.name = name;
		this.cost = cost;
	}
	public void gunDetails() {
		System.out.println(name);
		System.out.println(cost);
	}
}
