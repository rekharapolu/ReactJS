package spring_ioc_container;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BikeDriver {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("bike.xml");
		Bike bike=(Bike) context.getBean("mybike");
		bike.start();
		bike.stop();
	}

}
