package spring_ioc_container.constructor_injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeDriver {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("employee.xml");
		Employee employee=(Employee)context.getBean("myemployee");
		employee.employeeDetails();

	}

}
;