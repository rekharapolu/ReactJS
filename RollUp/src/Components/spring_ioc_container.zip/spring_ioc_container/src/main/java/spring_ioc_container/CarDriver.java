package spring_ioc_container;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class CarDriver {

	public static void main(String[] args) {
		/*
		 * ApplicationContext context=new ClassPathXmlApplicationContext("car.xml"); Car
		 * car=(Car) context.getBean("mycar"); System.out.println(car.cost(3000000));
		 * car.start();
		 */
	
					
				//core container
				Resource resource=new ClassPathResource("car.xml");
				BeanFactory factory=new XmlBeanFactory(resource);
				Car car=(Car) factory.getBean("mycar");
				System.out.println(car.cost(4000000));
				car.start();
	}
}
