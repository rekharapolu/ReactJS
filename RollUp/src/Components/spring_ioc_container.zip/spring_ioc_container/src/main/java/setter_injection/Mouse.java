package setter_injection;

public class Mouse {
	private String brand;
	private double price;
	private String color;
	private String type;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void mouseDetails() {
		System.out.println(brand);
		System.out.println(price);
		System.out.println(color);
		System.out.println(type);
	}
}
